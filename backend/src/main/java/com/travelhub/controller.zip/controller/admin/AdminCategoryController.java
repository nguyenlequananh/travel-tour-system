package com.travelhub.controller.admin;

import com.travelhub.dto.request.CategoryRequest;
import com.travelhub.dto.response.ApiResponse;
import com.travelhub.entity.TourCategory;
import com.travelhub.service.TourCategoryService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/admin/categories")
@RequiredArgsConstructor
public class AdminCategoryController {

    private final TourCategoryService categoryService;

    // 1. Lấy tất cả danh mục (Dành cho trang bảng danh mục của Admin)
    @GetMapping
    public ResponseEntity<ApiResponse<List<TourCategory>>> getAllCategories() {
        List<TourCategory> list = categoryService.getAllCategories();
        return ResponseEntity.ok(ApiResponse.<List<TourCategory>>builder()
                .status(200)
                .message("Lấy danh sách danh mục thành công")
                .data(list)
                .build());
    }

    // 2. Lấy chi tiết 1 danh mục theo ID (Khi bấm nút 'Sửa' trên React)
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<TourCategory>> getCategoryById(@PathVariable Integer id) {
        TourCategory category = categoryService.getCategoryById(id);
        return ResponseEntity.ok(ApiResponse.<TourCategory>builder()
                .status(200)
                .message("Lấy thông tin danh mục thành công")
                .data(category)
                .build());
    }

    // 3. Thêm mới danh mục
    @PostMapping
    public ResponseEntity<ApiResponse<TourCategory>> createCategory(@Valid @RequestBody CategoryRequest request) {
        TourCategory created = categoryService.createCategory(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.<TourCategory>builder()
                .status(201)
                .message("Tạo danh mục mới thành công")
                .data(created)
                .build());
    }

    // 4. Cập nhật danh mục
    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<TourCategory>> updateCategory(
            @PathVariable Integer id,
            @Valid @RequestBody CategoryRequest request) {
        TourCategory updated = categoryService.updateCategory(id, request);
        return ResponseEntity.ok(ApiResponse.<TourCategory>builder()
                .status(200)
                .message("Cập nhật danh mục thành công")
                .data(updated)
                .build());
    }

    // 5. Xóa danh mục
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteCategory(@PathVariable Integer id) {
        categoryService.deleteCategory(id);
        return ResponseEntity.ok(ApiResponse.<Void>builder()
                .status(200)
                .message("Xóa danh mục thành công")
                .data(null)
                .build());
    }
}