package com.travelhub.service;

import com.travelhub.dto.request.CancellationRequest;
import com.travelhub.dto.response.CancellationResponse;
import java.util.List;

public interface BookingCancellationService {
    CancellationResponse requestCancellation(CancellationRequest request);
    CancellationResponse getCancellationByBookingId(Long bookingId);
    List<CancellationResponse> getAllCancellations();
    CancellationResponse confirmRefund(Long cancellationId); // Kế toán duyệt bắn tiền hoàn lại
}