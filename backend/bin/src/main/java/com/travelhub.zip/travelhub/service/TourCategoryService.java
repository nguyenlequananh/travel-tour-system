package com.travelhub.service;

import com.travelhub.dto.request.CategoryRequest;
import com.travelhub.entity.TourCategory;
import java.util.List;

public interface TourCategoryService {
    List<TourCategory> getAllCategories();
    TourCategory getCategoryById(Integer id);
    TourCategory createCategory(CategoryRequest request);
    TourCategory updateCategory(Integer id, CategoryRequest request);
    void deleteCategory(Integer id);
}