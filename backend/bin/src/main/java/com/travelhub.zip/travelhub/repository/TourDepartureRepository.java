package com.travelhub.repository;
import com.travelhub.entity.TourDeparture;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
public interface TourDepartureRepository extends JpaRepository<TourDeparture, Long> {
    List<TourDeparture> findAllByTourId(Long tourId);
}
