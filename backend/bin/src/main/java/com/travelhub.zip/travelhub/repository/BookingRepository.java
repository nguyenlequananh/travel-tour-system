package com.travelhub.repository;
import com.travelhub.entity.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;
public interface BookingRepository extends JpaRepository<Booking, Long> {
    Optional<Booking> findBookingByBookingCode(String bookingCode);
    List<Booking> findAllByUserId(Long userId);
}
