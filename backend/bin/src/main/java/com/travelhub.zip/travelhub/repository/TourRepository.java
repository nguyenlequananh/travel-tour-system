package com.travelhub.repository;
import com.travelhub.entity.Tour;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TourRepository extends JpaRepository<Tour, Long> {
    boolean existsByTourCode(String tourCode);
    boolean existsByTourCodeAndIdNot(String tourCode, Long id);
}
