package com.travelhub.repository;
import com.travelhub.entity.BookingCancellation;
import org.springframework.data.jpa.repository.JpaRepository;
public interface BookingCancellationRepository extends JpaRepository<BookingCancellation, Long> {
    BookingCancellation findByBookingId(Long bookingId);    
    
}
