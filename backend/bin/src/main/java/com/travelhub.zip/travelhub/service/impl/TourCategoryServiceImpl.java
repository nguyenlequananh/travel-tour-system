package com.travelhub.service.impl;

import com.travelhub.dto.request.CategoryRequest;
import com.travelhub.entity.TourCategory;
import com.travelhub.repository.TourCategoryRepository;
import com.travelhub.service.TourCategoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class TourCategoryServiceImpl implements TourCategoryService {

    private final TourCategoryRepository categoryRepository;

    @Override
    public List<TourCategory> getAllCategories() {
        return categoryRepository.findAll();
    }

    @Override
    public TourCategory getCategoryById(Integer id) {
        return categoryRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy danh mục với ID: " + id));
    }

    @Override
    public TourCategory createCategory(CategoryRequest request) {
        if (categoryRepository.existsByName(request.getName())) {
            throw new RuntimeException("Tên danh mục này đã tồn tại!");
        }
        if (categoryRepository.existsBySlug(request.getSlug())) {
            throw new RuntimeException("Slug này đã tồn tại!");
        }

        TourCategory category = TourCategory.builder()
                .name(request.getName())
                .slug(request.getSlug().toLowerCase().trim())
                .description(request.getDescription())
                .build();

        return categoryRepository.save(category);
    }

    @Override
    public TourCategory updateCategory(Integer id, CategoryRequest request) {
        TourCategory category = getCategoryById(id);

        category.setName(request.getName());
        category.setSlug(request.getSlug().toLowerCase().trim());
        category.setDescription(request.getDescription());

        return categoryRepository.save(category);
    }

    @Override
    public void deleteCategory(Integer id) {
        TourCategory category = getCategoryById(id);
        categoryRepository.delete(category);
    }
}