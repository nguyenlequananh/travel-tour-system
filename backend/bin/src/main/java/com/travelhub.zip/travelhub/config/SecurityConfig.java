package com.travelhub.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable()) // Tắt CSRF để React/Postman gọi được POST/PUT/DELETE
            .authorizeHttpRequests(auth -> auth.anyRequest().permitAll()); // Tạm thời cho phép tất cả API
        return http.build();
    }
}